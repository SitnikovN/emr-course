from dataclasses import dataclass

@dataclass
class Config:
    SRC_DIR :str = None
    SRC_FMT :str = 'json'
    TGT_DIR :str = None
    TGT_FMT :str = 'parquet'
